package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.fragment.app.Fragment;

public  class fragment_Quiz1 extends Fragment {

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment__quiz1, container, false);
        ;
        ((RadioGroup) view.findViewById(R.id.radioOption)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                String selectedText = ((Button) view.findViewById(checkedId)).getText().toString();
                ((MainActivity) getActivity()).scoreAdd(0, selectedText, "Harper Lee");
            }
        });
        return view;
    }
}